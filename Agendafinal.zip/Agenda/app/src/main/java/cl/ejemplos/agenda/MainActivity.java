package cl.ejemplos.agenda;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import cl.ejemplos.agenda.Modelo.Persona;

public class MainActivity extends AppCompatActivity {
    private EditText etNombreP, etApellidoP, etCorreoP, etPasswordP;
    private ListView lvPersonas;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;
    private ArrayList<Persona> listaPersonas = new ArrayList<>();
    private ArrayAdapter<Persona> personaArrayAdapter;
    private Persona personaSeleccionada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etNombreP=(EditText) findViewById(R.id.txt_nombrePersona);
        etApellidoP =(EditText) findViewById(R.id.txt_apellidoPersona);
        etCorreoP=(EditText) findViewById(R.id.txt_correoPersona);
        etPasswordP=(EditText) findViewById(R.id.txt_passwordPersona);
        lvPersonas=(ListView) findViewById(R.id.lv_datosPersonas);

        iniciarFirebase();
        listarDatos();
        lvPersonas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                personaSeleccionada = (Persona) adapterView.getItemAtPosition(i);
                etNombreP.setText(personaSeleccionada.getNombre());
                etApellidoP.setText(personaSeleccionada.getApellido());
                etCorreoP.setText(personaSeleccionada.getCorreo());
                etPasswordP.setText(personaSeleccionada.getPassword());

            }
        });

    }

    private void listarDatos() {
        databaseReference.child("Persona").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaPersonas.clear();
                for(DataSnapshot obj: snapshot.getChildren())
                {
                    Persona persona = obj.getValue(Persona.class);
                    listaPersonas.add(persona);
                }
                personaArrayAdapter = new ArrayAdapter<Persona>( MainActivity.this,
                        android.R.layout.simple_list_item_1, listaPersonas);
                lvPersonas.setAdapter(personaArrayAdapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void iniciarFirebase() {
        FirebaseApp.initializeApp(this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.icon_add:
                String nombre=etNombreP.getText().toString();
                String apellido=etApellidoP.getText().toString();
                String correo=etCorreoP.getText().toString();
                String password=etPasswordP.getText().toString();

                if (nombre.equals("") || apellido.equals("") || correo.equals("") || password.equals(""))
                {
                    validacion(nombre,apellido,correo,password);
                }
                else
                {
                    Persona persona = new Persona();
                    persona.setUid(UUID.randomUUID().toString());
                    persona.setNombre(nombre);
                    persona.setApellido(apellido);
                    persona.setCorreo(correo);
                    persona.setPassword(password);

                    databaseReference.child("Persona").child(persona.getUid()).setValue(persona);
                    Limpiar();
                    Toast.makeText(this, "Agregado", Toast.LENGTH_SHORT).show();

                }
                break;
            case R.id.icon_delete:
                
                Persona personad = new Persona();
                personad.setUid(personaSeleccionada.getUid());
                databaseReference.child("Persona").child(personad.getUid()).removeValue();
                Limpiar();
                Toast.makeText(this, "Eliminado", Toast.LENGTH_SHORT).show();
                break;
            case R.id.icon_save:
                Persona persona = new Persona();
                persona.setUid(personaSeleccionada.getUid());
                persona.setNombre(personaSeleccionada.getNombre());
                persona.setApellido(personaSeleccionada.getApellido());
                persona.setCorreo(personaSeleccionada.getCorreo());
                persona.setPassword(personaSeleccionada.getPassword());

                databaseReference.child("Persona").child(persona.getUid()).setValue(persona);
                Limpiar();

                Toast.makeText(this, "Actualizado:" +personaSeleccionada.getNombre(), Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

    private void validacion(String nombre, String apellido,
                            String correo, String password)
    {
        if (nombre.equals(""))
        {
            etNombreP.setError(("Requerido"));
        }
        if (apellido.equals(""))
        {
            etApellidoP.setError(("Requerido"));
        }
        if (correo.equals(""))
        {
            etCorreoP.setError(("Requerido"));
        }
        if (password.equals(""))
        {
            etPasswordP.setError(("Requerido"));
        }
    }
    private void Limpiar()
    {
        etNombreP.setText("");
        etApellidoP.setText("");
        etCorreoP.setText("");
        etPasswordP.setText("");
    }
}